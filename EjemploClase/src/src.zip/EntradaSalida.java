import java.util.Scanner;
public class EntradaSalida {
	
	 public String leerTextoDeTeclado() {
	        Scanner entrada = new Scanner(System.in);
	        return entrada.nextLine();
	    }
	 public int leerIntTeclado() {
	        Scanner entrada = new Scanner(System.in);
	        return entrada.nextInt();
	    }

}
