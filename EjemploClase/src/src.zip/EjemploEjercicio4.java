import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;



public class EjemploEjercicio4 {
	
	public static void main(String[] args) throws FileNotFoundException, IOException {
		EntradaSalida es = new EntradaSalida();
		String nombreFichero=null;
		// TODO Auto-generated method stub
		
		System.out.println("Introduzca el nombre del fichero: ");
		nombreFichero=es.leerTextoDeTeclado();
		
		crearFicheroBinario(nombreFichero);
		
		
		}
		
		private static void crearFicheroBinario(String nombreFichero) throws FileNotFoundException, IOException {
	       
			int cod_pel=0;
			String nombre_pel = null;
			int Num_alquilada=0;
			String ruta ="src/";
			String ficha;
			
			
			//File fichero=new File(ruta+nombreFichero);
			// fichero=File(ruta);
             
		     //fichero.createNewFile();
			try (FileOutputStream flujoEscritura = new FileOutputStream(ruta+nombreFichero+".dat");
					DataOutputStream filtroEscritura=new DataOutputStream(flujoEscritura);
					
					){
				EntradaSalida es = new EntradaSalida();
                   
                    
                    System.out.println("Introduce codigo pelicula ");
					cod_pel=es.leerIntTeclado();
					
					
					System.out.println("Introduzca un nombre");
					nombre_pel=es.leerTextoDeTeclado();
					
					
					System.out.println("Introduzca numero alquiler ");
					Num_alquilada=es.leerIntTeclado();
					
					
				    String cadenaFinal=cod_pel+"@"+nombre_pel+"@"+Num_alquilada;
				    filtroEscritura.writeUTF(cadenaFinal);
				    
				System.out.println("Has introducido "+cadenaFinal);
		
	

} catch (FileNotFoundException e) {
	System.out.println("No pudo crearse el fichero");
}
		}
		

}